﻿namespace Factory.Data.Sql.Entities
{
    public class Norm
    {
        public int Id { get; set; }
        public int RawId { get; set; }
        public int ProductId { get; set; }
        public double quantity { get; set; }
    }
}
