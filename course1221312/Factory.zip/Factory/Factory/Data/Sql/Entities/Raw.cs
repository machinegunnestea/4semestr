﻿namespace Factory.Data.Sql.Entities
{
    public class Raw
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
