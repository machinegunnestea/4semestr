﻿namespace Factory.Data.Models
{
    public class Raw
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
