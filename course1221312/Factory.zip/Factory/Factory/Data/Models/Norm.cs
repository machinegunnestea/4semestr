﻿namespace Factory.Data.Models
{
    public class Norm
    {
        public int Id { get; set; }
        public Raw Raw { get; set; }
        public double Quantity { get; set; }
    }
}
