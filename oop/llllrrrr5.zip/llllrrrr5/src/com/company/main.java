package com.company;

import java.io.IOException;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;

public class main {

    public static void main(String[] args) throws IOException {
        task firstTask = new task();
        firstTask.showAllTask();

    }
}
