package com.company;

import java.io.IOException;


public class main {

    public static void main(String[] args) throws IOException {
        task secondtask = new task();
        secondtask.showAllSecondTask();

    }
}
